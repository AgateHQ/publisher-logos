<?php
/*
Plugin Name: Axate
Plugin URI: http://axate.com/
Description: Federated payment wallet and network allowing you to receive payments for your content
Version: 0.0.3
Author: Axate
Author URI: http://axate.com/
Text Domain: axate
License:
License URI:
*/

if (!defined('WPINC')) { die; }

require_once('inc/validation.php');
require_once('inc/base.php');
require_once('inc/settings.php');
