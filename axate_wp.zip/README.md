npm run build

autoupdate server:
https://github.com/YahnisElsts/plugin-update-checker