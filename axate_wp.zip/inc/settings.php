<?php

namespace Axate;

if (!defined('WPINC')) { die; }

require_once('singleton.php');

class Settings extends Singleton {
	public function init() {
		add_action('admin_menu', [$this, 'registerMenu']);
		add_action('admin_init', [$this, 'register']);
	}

	public function registerMenu() {
		add_options_page(
			'Axate settings',
			'Axate',
			'manage_options',
			'axate',
			[$this, 'renderPage']
		);
	}

	public function renderPage() {
		$settings = get_option('axate-settings') ?: [];
		$buttonLabel = __('Save', 'axate');
		?><div class="wrap">
			<h1><?php echo esc_html(get_admin_page_title()); ?></h1>
			<form action="options.php" method="post"><?php
				settings_fields('axate-settings');
				do_settings_sections('axate');
				submit_button($buttonLabel);
			?></form>
		</div><?php
	}

	public function register() {
		register_setting('axate-settings', 'axate-settings', [$this, 'validate']);
		add_settings_section('config', __('Configuration', 'axate'), [$this, 'renderConfigIntro'], 'axate');
		add_settings_field('mode',  '<label for="mode">' . __('Mode', 'axate') . '</label>', [$this, 'renderRadioButton'], 'axate', 'config', ['id' => 'mode', 'default' => 'staging', 'options' => ['staging' => __('Staging', 'axate'), 'production' => __('Production', 'axate')]]);
		add_settings_section('security', __('Security', 'axate'), [$this, 'renderSecurityIntro'], 'axate');
		add_settings_field('secret_key',  '<label for="secret_key">' . __('Secret key', 'axate') . '</label>', [$this, 'renderTextField'], 'axate', 'security', ['id' => 'secret_key']);
	}

	public function validate($input) {
		$valid = [];
		$keyFields = ['mode'];
		foreach ($keyFields as $key) {
			if (!isset($input[$key])) { continue; }
			$sanitized = sanitize_key($input[$key]);
			if (!empty($sanitized)) {
				$valid[$key] = $sanitized;
			}
		}
		$textFields = ['secret_key']; // `is_validate` and `excerpt_length` omitted to force revalidation
		foreach ($textFields as $key) {
			if (!isset($input[$key])) { continue; }
			$sanitized = sanitize_text_field($input[$key]);
			if (!empty($sanitized)) {
				$valid[$key] = $sanitized;
			}
		}
		return $valid;
	}

	public function renderConfigIntro() {
	}

	public function renderSecurityIntro() {
		echo '<p>' . __('Setting a secret key will activate authentication for REST API requests; this key should be shared with Axate so we can access the full content of articles.', 'axate') . '</p>';
	}

	public function renderTextField($args) {
		$settings = get_option('axate-settings') ?: [];
		?><input type="text" class="regular-text" id="<?php echo $args['id']; ?>" name="axate-settings[<?php echo $args['id']; ?>]" value="<?php echo isset($settings[$args['id']]) ? $settings[$args['id']] : ''; ?>"><?php
	}

	public function renderRadioButton($args) {
		$settings = get_option('axate-settings') ?: [];
		foreach ($args['options'] as $value => $label) {
			?><p><label><input type="radio" name="axate-settings[<?php echo $args['id']; ?>]" value="<?php echo $value; ?>"<?php echo (isset($settings[$args['id']]) && $settings[$args['id']] == $value) ? ' checked' : $value == $args['default'] ? 'checked' : ''; ?>><?php echo $label; ?></p><?php
		}
	}
}

Settings::instance()->init();
