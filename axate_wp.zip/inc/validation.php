<?php

namespace Axate;

if (!defined('WPINC')) { die; }

require_once('singleton.php');

class Validation extends Singleton {
	private $isValidated = false;
	private $validationError = false;
	private $validationUrl = 'http://staging.agate.io/api/wp';
	private $supportEmail = 'support@axate.com';

	public function init() {
		$settings = get_option('axate-settings') ?: [];
		if (isset($settings['mode']) && $settings['mode'] == 'production') {
			$this->validationUrl = 'http://agate.io/api/wp';
		}
	}

	public function checkValidity() {
		$settings = get_option('axate-settings') ?: [];
		if (isset($settings['is_validated']) && $settings['is_validated'] === true) {
			$this->isValidated = true;
			return true;
		} else if (is_admin()) {
			return $this->validate();
		} else {
			return false;
		}
	}

	public function displayValidationError() {
		$message = __('<strong>Axate</strong>: site not validated', 'axate') . ($this->validationError ? ' &ndash; ' . $this->validationError : '') . '. <a href="' . $_SERVER['REQUEST_URI'] . '">' . __('Try again', 'axate') . '</a> or <a href="mailto:' . $this->supportEmail . '">contact support</a>.</a>';
		?><div class="notice notice-error is-dismissible">
			<p><?php echo $message; ?></p>
		</div><?php
	}

	public function validate() {
		$settings = get_option('axate-settings') ?: [];
		$url = get_bloginfo('url');
		$request = wp_remote_get($this->validationUrl . '?url=' . $url);

		// Check response is well formed
		if (is_wp_error($request)) {
			$this->validationError = __('could not contact Axate server', 'axate');
		} else if (isset($request['http_request_failed'])) {
			$this->validationError = __('HTTP request failed', 'axate');
		} else if (!isset($request['http_response'])) {
			$this->validationError = __('HTTP response missing', 'axate');
		} else if (!isset($request['body'])) {
			$this->validationError = __('response body missing', 'axate');
		}

		// Escape on error
		if ($this->validationError !== false) {
			add_action('admin_notices', [$this, 'displayValidationError']);
			return false;
		}

		// Check contents
		$data = json_decode($request['body']);
		if (!is_object($data)) {
			$this->validationError = __('unexpected server response', 'axate');
		} else if (property_exists($data, 'error')) {
			$this->validationError = property_exists($data, 'details') ? $data->details : __('unknown error', 'axate');
		} else if (property_exists($data, 'success') && $data->success === true) {
			$settings['is_validated'] = true;
			if (property_exists($data, 'excerptLength') && $data->excerptLength > 0) {
				$settings['excerpt_length'] = $data->excerptLength;
			}

			// Validated OK, save settings
			update_option('axate-settings', $settings);
			return true;
		} else {
			$this->validationError = __('your site was not validated', 'axate') . ': ';
		}

		// Failed if we're still here
		add_action('admin_notices', [$this, 'displayValidationError']);
		return false;
	}
}

Validation::instance()->init();
