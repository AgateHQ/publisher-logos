<?php

namespace Axate;

if (!defined('WPINC')) { die; }

class Singleton {
	public static function instance() {
		static $instance;
		if ($instance === null) {
			$instance = new static();
		}
		return $instance;
	}
	private function __construct() {}
	private function __clone() {}
	private function __sleep() {}
	private function __wakeup() {}
}
