<?php

namespace Axate;

if (!defined('WPINC')) { die(); }

require_once('validation.php');
require_once('singleton.php');

class Base extends Singleton {
	private $paidClass = 'axate-paid-article';
	private $noticeClass = 'axate-notice';
	private $defaultExcerptLength = 600;
	private $walletUrl = 'https://wallet-staging.agate.io/bundle.js';

	public function init() {
		if (Validation::instance()->checkValidity()) {
			$settings = get_option('axate-settings') ?: [];
			if (isset($settings['mode']) && $settings['mode'] == 'production') {
				$this->walletUrl = 'https://wallet.agate.io/bundle.js';
			}
			add_action('init', [$this, 'registerStructure']);
			add_action('init', [$this, 'registerAssets']);
			add_action('wp_head', [$this, 'insertScript']);
			add_action('wp_footer', [$this, 'insertWallet']);
			add_filter('the_content', [$this, 'filterContent'], 999999999);
			add_filter('rest_authentication_errors', [$this, 'authenticateRestRequests']);
		}
	}

	public function registerStructure() {
		register_post_meta('', 'axate_is_paid', [
			'show_in_rest' => true,
			'single'       => true,
		]);
	}

	public function registerAssets() {
		$handle = 'axate';
		$jsPath = 'build/index';
		$url = plugins_url($jsPath . '.js', dirname(__FILE__));
		$meta = require(plugin_dir_path(dirname(__FILE__)) . $jsPath . '.asset.php');
		wp_enqueue_script($handle, $url, $meta['dependencies'], $meta['version']);

		$cssPath = 'build/index.css';
		wp_enqueue_style($handle, plugins_url($cssPath, dirname(__FILE__)), [], filemtime(plugin_dir_path(dirname(__FILE__)) . $cssPath));
	}

	public function insertScript() {
		?><script async src="<?php echo $this->walletUrl; ?>"></script><?php
	}

	public function insertWallet() {
		?><div id="axate-wallet" data-selector-premium-content=".<?php echo $this->paidClass; ?>" data-selector-in-page-notice=".<?php echo $this->noticeClass; ?>"></div><?php
	}

	public function filterContent($content) {
		if (defined('REST_REQUEST') && REST_REQUEST) { return $content; }
		$postId = get_the_ID(); // Works in the loop on single and category pages
		if (!$postId) { return $content; }
		if (get_post_meta($postId, 'axate_is_paid', true) !== '1') { return $content; }
		$excerptLength = $this->defaultExcerptLength;
		$settings = get_option('axate-settings') ?: [];
		if (isset($settings['excerpt_length']) && is_numeric($settings['excerpt_length'])) {
			$excerptLength = $settings['excerpt_length'];
		}
		return '<div class="axate-wrapper"><div class="' . $this->noticeClass . '"></div><div class="' . $this->paidClass . '">' . substr(strip_tags(html_entity_decode($content)), 0, $excerptLength) . '</div></div>';
	}

	public function authenticateRestRequests($access) {

		// User is logged into WordPress, allow
		if (is_user_logged_in()) { return $access; }

		// No secret key set in settings, allow
		$settings = get_option('axate-settings') ?: [];
		if (empty($settings['secret_key'])) { return $access; }

		// Today's GMT date (Ymd), hashed with secret key, sha521 algo, passed as Axate-Auth HTTP header, allow
		if (isset($_SERVER['HTTP_AXATE_AUTH']) && $_SERVER['HTTP_AXATE_AUTH'] === hash_hmac('sha512', gmdate('Ymd'), $settings['secret_key'])) { return $access; }

		// Still here? Deny
		return new \WP_Error('rest_login_required', 'REST authorisation required', array('status' => rest_authorization_required_code()));
	}
}

Base::instance()->init();
